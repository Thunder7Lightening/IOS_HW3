//
//  PlayingCard.swift
//  PokerCardGame
//
//  Created by student on 2018/4/16.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

struct PlayingCard:CustomStringConvertible{
    
    // when print("\(card)")
    var description: String{
        return "\(rank)\(suit)"
    }
    
    var suit:Suit
    var rank:Rank
    
    var isFaceUp:Bool
    
    
    enum Suit:String, CustomStringConvertible {
        var description: String{
            return "\(self.rawValue)"
        }
        
        case spades = "♠️"
        case hearts = "♥️"
        case diamonds = "♦️"
        case clubs = "♣️"
        
        static var all = [Suit.spades, Suit.hearts, Suit.diamonds, Suit.clubs]
    }
    
    enum Rank:CustomStringConvertible{
        var description: String{
            switch self {
            case .ace: return "A"
            case .numeric(let pips): return "\(pips)"
            case .face(let kind): return kind
            default: return "?"
            }
        }
        
        case ace
        case numeric(Int)
        case face(String)
        
        var order:Int{
            switch self{
            case .ace: return 1
            case .numeric(let pips): return pips
            case .face(let kind) where kind == "J": return 11
            case .face(let kind) where kind == "Ｑ": return 12
            case .face(let kind) where kind == "K": return 13
            default: return 0
            }
        }
        
        static var all:[Rank]{
            var allRanks = [Rank.ace]
            for pips in 2...10{
                allRanks.append(Rank.numeric(pips))
            }
            allRanks += [Rank.face("J"), .face("Q"), .face("K")]
            return allRanks
        }
    }
}
